This is literally the multiplayer pause mod your parents have been wanting you to install :)

If the host presses 'p' the game will pause for all players.


